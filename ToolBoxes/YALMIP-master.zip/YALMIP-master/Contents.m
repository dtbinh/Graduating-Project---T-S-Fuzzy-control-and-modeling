% YALMIP
% Version 18-Aug-2017
% Help on http://yalmip.github.io
