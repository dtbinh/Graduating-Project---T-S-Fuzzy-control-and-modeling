function F = set(F,tag)

disp('SET has been considered obsolete for many years, and the time has come...');
disp('Update your code. http://users.isy.liu.se/johanl/yalmip/pmwiki.php?n=Commands.set');
error('Obsolete command')
